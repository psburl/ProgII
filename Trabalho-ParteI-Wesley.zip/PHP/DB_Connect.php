<?php 
	$DB_Connect =   pg_connect("host=localhost dbname=ItsMyLife user=postgres  password=psr-e323 port=5432") or die ('Erro  ao conectar com o servidor');
?> 